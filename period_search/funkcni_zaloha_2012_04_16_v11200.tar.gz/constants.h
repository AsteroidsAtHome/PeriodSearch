#define POINTS_MAX         2000             /* max number of data points in one lc. */
#define MAX_N_OBS         10000             /* max number of data points */
#define MAX_LC              200             /* max number of lightcurves */
#define MAX_LINE_LENGTH    1000             /* max length of line in an input file */
#define MAX_N_FAC          1000             /* max number of facets */
#define MAX_N_ITER          100             /* maximum number of iterations */
#define MAX_N_PAR           300             /* maximum number of parameters */
#define MAX_N_POLES        3000             /* maximum number of poles in pole search */
#define MAX_LM               15             /* maximum degree and order of sph. harm. */
#define N_PHOT_PAR            5             /* maximum number of parameters in scattering  law */
#define EPSILON               0             /* precision parameter */
#define TINY                  1e-8          /* precision parameter for mu, mu0*/
#define ADD_SMALL             1e-200        /* to avoid singular matrix in gauss_1 */
#define MAX_YORP              1.5e-7        /* max. YORP at 1 AU for 1 km in days^{-2} */
#define YORP_TRIALS           5		    /* number of trials per 360 deg */

#define PI                    3.14159265358979323846
#define AU            149597870.691         /* Astronomical Unit [km] */
#define C_SPEED       299792458             /* speed of light [m/s]*/

#define DEG2RAD      (PI / 180)
#define RAD2DEG      (180 / PI)
